print("Ejercicio 1")
print("ingrese un numero entero")
v1 = input()
xnum = int(v1)
if xnum > 0:
    print ("su numero es positivo")
elif xnum < 0:
    print("su numero es negativo")
else: 
    print("su numero es 0")

