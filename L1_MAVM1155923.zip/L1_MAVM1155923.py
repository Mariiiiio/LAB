'''variable1 = 21000 #
print("comentario")
print(variable1)
print(type(variable1))

variable1 = "hola"
print(variable1)
print(type(variable1))

variable2 = 123.1
print(variable2)
print(type(variable2))

variable3 = False
print(variable3)
print(type(variable3))'''

#print("hola mundo soy Mario")
'''print("hola mundo")
print("soy Mario")
# significa que continuara en la siguiente linea
print("hola mundo ", end="")
print("soy Mario", end="")'''
# significa que continuara en la misma linea

print("ingrese su nombre")
texto = input()
print("hola " + texto)